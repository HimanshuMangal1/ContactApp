package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.dao.ContactDAO;


public class DeleteContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		

		String i_d=request.getParameter("id");
		int id1=Integer.parseInt(i_d);
		
	    ContactDAO cd=new ContactDAO();
	    cd.deletebyId(id1);
	    
	    
	    PrintWriter writer=response.getWriter();
	    
	    writer.write("delete Sucefffully");
	    
	   
	    response.sendRedirect("ViewAllContact");
		
	    
	    
	}

}
