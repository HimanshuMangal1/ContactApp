package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.bean.ContactPOJO;
import com.hefshine.dao.ContactDAO;


public class AddContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("name");
		String number=request.getParameter("number");
		String email=request.getParameter("email");
		
		
		ContactPOJO contact=new ContactPOJO();
		contact.setName(name);
		contact.setNumber(number);
		contact.setEmail(email);
		
		ContactDAO cd=new ContactDAO();
		cd.save(contact);
		
		PrintWriter writer=response.getWriter();
		writer.write("Contact added Susesscfully");
		response.sendRedirect("ViewAllContact");
		
		writer.write("<a href='index.html'>Welcome Page</a>");
		
		
		
		
		
		
	}

}
