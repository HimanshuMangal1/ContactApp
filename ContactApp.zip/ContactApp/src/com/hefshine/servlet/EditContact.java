package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hefshine.bean.ContactPOJO;
import com.hefshine.dao.ContactDAO;


public class EditContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String i_d=request.getParameter("id");
		int id1=Integer.parseInt(i_d);
		
		HttpSession session =request.getSession();
		session.setAttribute("id", id1);
		
		
	    ContactDAO cd=new ContactDAO();
	    
	    ContactPOJO contact=cd.getById(id1);
	    
	    PrintWriter writer=response.getWriter();
	    writer.write(" <form action='Update'>   ");
	    
	    writer.write(" Id   : <input type='text' name='id' value="+contact.getId()+">  <br><br><br>");
	    
	    writer.write(" Name :<input type='text' name='name' value="+contact.getName()+">  <br><br><br>");
	    
	    writer.write(" Number :<input type='text' name='number' value="+contact.getNumber()+"> <br><br> <br>");
	    
	    writer.write(" Email :<input type='text' name='email' value="+contact.getEmail()+">  <br><br><br>");
	   
	    writer.write("       <input type='submit'  value='Uddate'>");
		   
	    writer.write(" </form");
		
		
		
		
	}

}
