package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.bean.ContactPOJO;
import com.hefshine.dao.ContactDAO;


public class ViewAllContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		ContactDAO cd=new ContactDAO();
		
		List<ContactPOJO> contactlist= cd.getAll();
		
		PrintWriter writer=response.getWriter();
		
		writer.write("<a href ='add-new-contact.html'> Add New Contacts</a>");
		writer.write("<table border ='1px solid'>");
				
				writer.write("<tr>");
			     writer.write("<td>id</td>");
			     writer.write("<td>name</td>");
			     writer.write("<td>number</td>");
			     writer.write("<td>email</td>");
			     writer.write("<td>Edit</td>");
			     writer.write("<td>Delete</td>");
			     
			     
		     writer.write("</tr>"); 
	     
		     contactlist.forEach(a ->{
		    	 writer.write("<tr>");
			     writer.write("<td>"+a.getId()+"</td>");
			     writer.write("<td>"+a.getName()+"</td>");
			     writer.write("<td>"+a.getNumber()+"</td>");
			     writer.write("<td>"+a.getEmail()+"</td>");
			     writer.write("<td>"+"<a href ='EditContact?id="+a.getId()+"'>Edit</a>"+"</td>");
			     writer.write("<td>"+"<a href ='DeleteContact?id="+a.getId()+"'>Delete</a>"+"</td>");
			    
			     
		     writer.write("</tr>"); 

		    	 
		     });
			
				
		
		writer.write("</table>");
		
		
		 writer.write("<a href='index.html'>Welcome Page</a>");
			
		
		
		
		
	}

}
