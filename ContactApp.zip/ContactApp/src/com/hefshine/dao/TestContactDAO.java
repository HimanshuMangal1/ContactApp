package com.hefshine.dao;

public class TestContactDAO {

	public static void main(String[] args) {
		ContactDAO cd=new ContactDAO();
		System.out.println(cd.getAll());
		

	}

}
