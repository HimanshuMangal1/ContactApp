package com.hefshine.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hefshine.bean.ContactPOJO;

public class ContactDAO {
	
	
	private String DB_URL="jdbc:mysql://localhost:3306/hefshine";
	private String USERNAME="root";
	private String PASSWORD="root";
	
	
	public void save(ContactPOJO contact)
	{
		
		try
		{
            Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			
			String query="INSERT INTO contact (name,number,email) Values(?,?,?)";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			
					
			pst.setString(1, contact.getName());
			pst.setString(2, contact.getNumber());
			pst.setString(3, contact.getEmail());
			
			pst.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
	
	public List<ContactPOJO> getAll()
	{
		List<ContactPOJO> mycontact=new  ArrayList <ContactPOJO>();
		
		try
		{
            Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			
			String query="SELECT * FROM contact";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				ContactPOJO c=new ContactPOJO();
				c.setId(rs.getInt("id"));
				c.setName(rs.getString("name"));
				c.setNumber(rs.getString("number"));
				c.setEmail(rs.getString("email"));
				mycontact.add(c);
				
			}
					
		
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return mycontact;
		
	}
	
	
	public void update(ContactPOJO contact)
	{
		try
		{
            Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			
			String query="UPDATE contact SET name=?,number=?,email=? where id=?";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			pst.setString(1, contact.getName());
			pst.setString(2, contact.getNumber());
			pst.setString(3, contact.getEmail());
			pst.setInt(4, contact.getId());
			
			pst.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	public ContactPOJO getById(int id)
	{
		ContactPOJO contact=new ContactPOJO();
		try
		{
            Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			
			String query="SELECT * FROM contact where id=?";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			pst.setInt(1, id);
			
		    ResultSet rs=pst.executeQuery();
		
			while(rs.next())
			{
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setNumber(rs.getString("number"));
				contact.setEmail(rs.getString("email"));
			
				
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return contact;
	}


	public void deletebyId(int id)
	{
		try
		{
            Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
			
			String query="DELETE FROM contact  where id=?";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
	
			pst.setInt(1, id);
			
			pst.execute();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
